package info.pauek.shoppinglist;

public class ShoppingItem {
    private String name;
    private boolean check;

    public ShoppingItem(String name) {
        this.name = name;
        this.check=false;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isCheck(){

        return  check;
    }

    public  void setcheck(boolean check)
    {
        this.check=check;
    }
}
